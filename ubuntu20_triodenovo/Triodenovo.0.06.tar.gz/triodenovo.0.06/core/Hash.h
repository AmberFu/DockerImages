#ifndef __HASH_H__
#define __HASH_H__

unsigned int hash ( const unsigned char * key, unsigned int length, unsigned int initval);

unsigned int hash_no_case ( const unsigned char * key, unsigned int length, unsigned int initval);

#endif

