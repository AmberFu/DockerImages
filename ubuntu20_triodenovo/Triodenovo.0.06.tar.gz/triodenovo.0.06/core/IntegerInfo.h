#ifndef __INTEGERINFO_H__
#define __INTEGERINFO_H__

#include "StringBasics.h"

String & IntegerInfo(double bytes);

#endif

