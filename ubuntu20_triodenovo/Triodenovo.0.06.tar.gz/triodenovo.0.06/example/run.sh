
../src/triodenovo  --ped trio.denovo.ped  --in_vcf trio.denovo.vcf --out_vcf trio.denovo.vcf.out
