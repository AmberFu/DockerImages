#ifndef __CMDLINEPAR_H__
#define __CMDLINEPAR_H__

#include "StringArray.h"
#include  <string>

class CmdLinePar
{
public:
std::string cmd;
int minTotalDepth;
int maxTotalDepth;
int minDepthInTrio;
int maxDepthInTrio;
double minAvgDepth;
double maxAvgDepth;
double theta;
double theta_indel;
double tstv_ratio;
double min_lbf;
double mutation_rate;
bool double_mutant;
String chrX_label;
String chrY_label;
String MT_label;
String vcfInFile;
String vcfOutFile;
bool mixed_vcf_records;

public:
CmdLinePar() {
  theta = .0;
  minTotalDepth = 0;
  maxTotalDepth = 0;
  minAvgDepth = 0.;
  maxAvgDepth = 0.;
  theta = 0.001;
  theta_indel = 0.001;
  tstv_ratio = 2.0;
  min_lbf = 0;
  double_mutant = false;
  mutation_rate = 1e-5;
  String chrX_label = "";
  String chrY_label = "";
  String MT_label = "";
 }
};
        
#endif
