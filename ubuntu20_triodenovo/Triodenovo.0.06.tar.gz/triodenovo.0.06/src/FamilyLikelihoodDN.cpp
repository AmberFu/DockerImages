#include "FamilyLikelihoodDN.h"
#include "Error.h"

#define GLLIM 1023

FamilyLikelihoodDN::FamilyLikelihoodDN()
{
 ped = NULL;
 GL_idx = -1;
 PL_idx = -1;
 GT_index = -1;
 GQ_index = -1;
 DP_index = -1;
 QUAL = 0;
 isIndel = false;
 pid_match = false;
 isChrX = false;
 isChrY = false;
 isMT = false;
 withdata_cnt = 0;
 nSamplesWithData = 0;
 for(int i=0; i<=GLLIM; i++)
  PL2LK_table[i] = pow(10, -double(i)/10.0);
 std::string labels[10] = {"A/A", "A/C", "A/G", "A/T", "C/C", "C/G", "C/T", "G/G", "G/T", "T/T"};
 std::string labels_X_Male[10] = {"A", "NA", "NA", "NA", "C", "NA", "NA", "G", "NA", "T"};
 genotype10_labels.resize(10);
 genotype10_labels_X_Male.resize(10);
 for(int i=0; i<10; i++) { genotype10_labels[i] = labels[i]; genotype10_labels_X_Male[i] = labels_X_Male[i];}
}

FamilyLikelihoodDN::~FamilyLikelihoodDN(){}


void FamilyLikelihoodDN::SetPedigree(Pedigree* p)
{
  ped = p;
  trio_info.resize(ped->familyCount);
  MapPID2Traverse();
  GetSexes();
  InitFamilyLikelihoodES();
}

void FamilyLikelihoodDN::MapPID2Traverse()
{
    pid2traverse.clear();
    pids.clear();

    for(int i=0; i<ped->familyCount; i++)
        for(int j=0; j<ped->families[i]->count; j++)
        {
            std::pair<int, int> traverse_pair;
            traverse_pair.first = i;
            traverse_pair.second = j;

            Person *p;
            p = ped->persons[ped->families[i]->path[j]];
            pid2traverse[std::string(p->pid.c_str())] = traverse_pair;
            pids.push_back(std::string(p->pid.c_str()) );
        }
}

int FamilyLikelihoodDN::Allele2Int(std::string& allele)
{
 if(!allele.compare("A") || !allele.compare("a") ) return (1);
 if(!allele.compare("C") || !allele.compare("c") ) return (2);
 if(!allele.compare("G") || !allele.compare("g") ) return (3);
 if(!allele.compare("T") || !allele.compare("t") ) return (4);
 return(0);
}

double FamilyLikelihoodDN::PL2LK(int pl)
{
  if(pl<0) error("Phred-scaled likelihood %d can not be negative\n", pl);
  if(pl>GLLIM) return(PL2LK_table[GLLIM]);
  return(PL2LK_table[pl]);
}

void FamilyLikelihoodDN::GetSexes()
{
 sexes.resize(ped->familyCount);
 for(int i=0; i<ped->familyCount; i++)
 {
  sexes[i].resize(ped->families[i]->count);
  for(int j=0; j<ped->families[i]->count; j++)
  {
   Person *p = ped->persons[ped->families[i]->path[j]];
   sexes[i][j] = p->sex;
   if(p->sex==MALE && p->isFounder()) maleFounders++;
   if(p->sex==FEMALE && p->isFounder()) femaleFounders++;
  }
 }
}

void FamilyLikelihoodDN::InitFamilyLikelihoodES()
{
  for(int i=0; i<ped->familyCount; i++)
  {
    if(ped->families[i]->isNuclear()==false) error("Family %s is not a trio\n", ped->families[i]->famid.c_str() );
    if(ped->families[i]->count!=3) error("Family %s is not a trio\n",ped->families[i]->famid.c_str() );
    if(ped->families[i]->founders!=2) error("Family %s is not a trio\n", ped->families[i]->famid.c_str() );
  }

  SetDenovoMutationModel();

  fam = new FamilyLikelihoodES[ped->familyCount];
  for(int i=0; i<ped->familyCount; i++)
    {
      fam[i].SetPedigree(ped);
      fam[i].SetFamily(ped->families[i]);
      fam[i].SetFamilyIndex(i);
      fam[i].SetTransmissionMatrix();
      fam[i].SetTransmissionMatrix_BA();
      fam[i].SetTransmissionMatrix_BA_CHRX_2Female();
      fam[i].SetTransmissionMatrix_BA_CHRX_2Male();
      fam[i].SetTransmissionMatrix_BA_CHRY();
      fam[i].SetTransmissionMatrix_BA_MITO();

      //Setup poly prior for a single family
      fam[i].SetSingleFamilyPolyPrior(par.theta);
      fam[i].SetSingleFamilyPolyPrior_indel(par.theta_indel);

      //Setup prarentPrior for a single nuclear family
      fam[i].SetParentPriorSingleTrio(fam[i].poly_prior);
      fam[i].SetParentPriorSingleTrio_indel(fam[i].poly_prior_indel);

      //Setup mutation model
      fam[i].SetGenotypeMutationModel(&gM);
      fam[i].SetTransmissionMatrix_denovo();
      fam[i].CalcPostDenovoMatrix(par.mutation_rate);
      //fam[i].PrintTransmissionMatrix_denovo();
      //fam[i].PrintTransmissionMatrix_denovo_post();

      //if(ped->families[i]->count!=ped->families[i]->founders) fam[i].PreparePeeling();
    }
}

void FamilyLikelihoodDN::FillPenetrance()
{
 r = &vin->getVCFRecord(); 
 people = &r->getPeople();

 refStr = r->getRef();
 altStr = r->getAlt();
 position = r->getPos();

 for(int i=0; i<ped->familyCount; i++)
 {
  fam[i].loglk.Set(-GLLIM/10.0);
  fam[i].penetrances.Set(PL2LK_table[GLLIM]);
 }

  std::map<std::string, std::pair<int, int> >::iterator it;
  StringArray gl;
  VCFIndividual* indv;

  if(nSamplesWithData==0)
  for(int i=0; i<people->size(); i++)
  {
      indv = (*people)[i];
//      it = pid2traverse.find( (*indv).getName() ); //Note: this should be done only once on the header line. Will optimaize later
//      if(it==pid2traverse.end() ) continue; //Note: after the above, this should be checked a vector of bools
        if(pid2traverse.count((*indv).getName())==0) {
	 //printf("Sample ID \"%s\" not included in the analysis!\n", (*indv).getName().c_str());
	 continue; }
        nSamplesWithData++;
  }

 if(refStr.compare(altStr)==0) { isBiallelic = false; return; } // Ignore monomorphic sites.

 isBiallelic = true;
 for(int s=0; s<altStr.size();s++)
  if(altStr[s]==',')
    { isBiallelic = false; return; }

 isIndel =  (refStr.size()>1 || altStr.size()>1) ? true : false;

 ref = isIndel ? 1 : Allele2Int(refStr);
 alt = isIndel ? 2 : Allele2Int(altStr);
 allele1 = ref;
 allele2 = alt;
 alleles[0] = ref;
 alleles[1] = alt;
 genotype_index[0] = GenotypeIndex(allele1, allele1);
 genotype_index[1] = GenotypeIndex(allele1, allele2);
 genotype_index[2] = GenotypeIndex(allele2, allele2);

  if(DP_index<0)
  {
        DP_index = r->getFormatIndex("DP");
  }

  if(GL_idx<0 && PL_idx<0)
  {
      GL_idx = r->getFormatIndex("GL");
      PL_idx = r->getFormatIndex("PL");


      if(GL_idx<0 && PL_idx<0) {
         fprintf(stderr, "\nNO GL or PL field was found. Please check the vcf file at chr:%s and position:%d\n\n", r->getChrom(), r->getPos());
          exit(1);
       }

     for(int i=0; i<people->size(); i++)
      {
        indv = (*people)[i];
        it = pid2traverse.find( (*indv).getName() );
        if(it!=pid2traverse.end()) { pid_match = true; break;}
      }

    if(pid_match==false) error("NO individual IDs match in the ped and vcf file!\n");
   }

  if(par.mixed_vcf_records)
  {
      GL_idx = -1; PL_idx = -1;
      GL_idx = r->getFormatIndex("GL");
      PL_idx = r->getFormatIndex("PL");


      if(GL_idx<0 && PL_idx<0) {
         fprintf(stderr, "\nNO GL or PL field was found. Please check the vcf file at chr:%s and position:%d\n\n", r->getChrom(), r->getPos());
          exit(1);
       }

  }

   if(isBiallelic==false) return;

   withdata_cnt = 0;

    for(int i=0; i<people->size(); i++)
    {
        indv = (*people)[i];
        it = pid2traverse.find( (*indv).getName() ); //Note: this should be done only once on the header line. Will optimaize later
        if(it==pid2traverse.end() ) continue; //Note: after the above, this should be checked a vector of bools

        bool missing = false;

        int gt_idx0 = glfHandler::GenotypeIndex(ref, ref);
        int gt_idx1 = glfHandler::GenotypeIndex(ref, alt);
        int gt_idx2 = glfHandler::GenotypeIndex(alt, alt);

        gl.ReplaceTokens(String( GL_idx>0 ? (*indv).get(GL_idx, &missing).toStr() : (*indv).get(PL_idx, &missing).toStr() ), ",");

        if(missing || gl.Length()!=3 ) {
          fam[it->second.first].loglk[it->second.second][gt_idx0] = 0.0;
          fam[it->second.first].loglk[it->second.second][gt_idx1] = 0.0;
          fam[it->second.first].loglk[it->second.second][gt_idx2] = 0.0;

          fam[it->second.first].penetrances[it->second.second][gt_idx0] = 1.0;
          fam[it->second.first].penetrances[it->second.second][gt_idx1] = 1.0;
          fam[it->second.first].penetrances[it->second.second][gt_idx2] = 1.0; 

          return;
         }

//        if(gl.Length()!=3) error("GL or PL filed does not have 3 values separated by commas at: %s %d!\n", r->getChrom(), r->getPos());

        double GL0 = gl[0].AsDouble();
        double GL1 = gl[1].AsDouble();
        double GL2 = gl[2].AsDouble();

        if(GL0!=0.0 || GL1!=0.0 || GL2!=0.0) withdata_cnt++;

        fam[it->second.first].loglk[it->second.second][gt_idx0] = PL_idx>0 ? (GL0 > GLLIM ? -GLLIM/10.0 : -GL0/10.0) : (-10*GL0>GLLIM ? -GLLIM/10.0 : GL0);
        fam[it->second.first].loglk[it->second.second][gt_idx1] = PL_idx>0 ? (GL1 > GLLIM ? -GLLIM/10.0 : -GL1/10.0) : (-10*GL1>GLLIM ? -GLLIM/10.0 : GL1);
        fam[it->second.first].loglk[it->second.second][gt_idx2] = PL_idx>0 ? (GL2 > GLLIM ? -GLLIM/10.0 : -GL2/10.0) : (-10*GL2>GLLIM ? -GLLIM/10.0 : GL2);

        fam[it->second.first].penetrances[it->second.second][gt_idx0] = PL2LK(int(PL_idx>0 ? GL0 : -10*GL0));
        fam[it->second.first].penetrances[it->second.second][gt_idx1] = PL2LK(int(PL_idx>0 ? GL1 : -10*GL1));
        fam[it->second.first].penetrances[it->second.second][gt_idx2] = PL2LK(int(PL_idx>0 ? GL2 : -10*GL2));


//      printf("pos=%d pene=%f %f %f\n",  r->getPos(), fam[it->second.first].penetrances[it->second.second][gt_idx0],fam[it->second.first].penetrances[it->second.second][gt_idx1],fam[it->second.first].penetrances[it->second.second][gt_idx2] );

    } //end of iterating all individuals in a VCF record
}

void FamilyLikelihoodDN::FillZeroPenetrance(int fam_idx, int person_idx, int geno_idx)
{
 for(int i=0; i<10; i++)
  if(geno_idx != i) fam[fam_idx].penetrances[person_idx][i]=0;
}

void FamilyLikelihoodDN::SetDenovoMutationModel()
{
  aM.SetMutationRate(par.mutation_rate);
  aM.SetTsTvRatio(par.tstv_ratio);
  aM.SetAlleleMutMatrix();
  gM.SetGenoMutMatrix(aM);
}

double FamilyLikelihoodDN::GetPrior_ts(double tstv_ratio)
{
  return(tstv_ratio/(tstv_ratio + 1));
}

double FamilyLikelihoodDN::GetPrior_tv(double tstv_ratio)
{
  return(0.5/(tstv_ratio+1));
}

bool FamilyLikelihoodDN::isTs(int a1, int a2)
{
 return ( ( (a1==1 && a2==3) || (a1==2 && a2==4) ) ? true : false );
}

bool FamilyLikelihoodDN::isTv(int a1, int a2)
{
 return(!isTs(a1, a2));
}

/*
void FamilyLikelihoodDN::SetPolyPrior_chrX()
{
  prior = 0;
  if(ped->founders==0)
    error("Family size is zero\n");
  
  for(int i=1; i<=(pedGLF->femaleFounders*2+pedGLF->maleFounders); i++) //number of chromosomes
    prior += 1.0 / i;
  priorFreq = 1-1./prior;
  prior *= theta;  
  
}

void FamilyLikelihoodDN::SetPolyPrior_chrY()
{
  prior = 0;
  if(nFounders==0)
    error("Family size is zero\n");
  
  for(int i=1; i<=pedGLF->maleFounders; i++) //number of chromosomes
    prior += 1.0 / i;
  priorFreq = 1-1./prior;
  prior *= theta;  
  
}

void FamilyLikelihoodDN::SetPolyPrior_MT()
{
  prior = 0;
  if(nFounders==0)
    error("Family size is zero\n");
  
  for(int i=1; i<=nFounders; i++) //number of chromosomes
    prior += 1.0 / i;
  priorFreq = 1-1./prior;
  prior *= theta;  
  
}

void FamilyLikelihoodDN::SetPolyPrior(int famIdx)
{
  prior = 0;
  if(ped->families[famIdx]->founders==0)
    error("Family size is zero\n");

  for(int i=1; i<=2*ped->families[famIdx]->founders; i++) //number of chromosomes
    prior += 1.0 / i;
  prior *= par.theta;

}

void FamilyLikelihoodDN::SetPolyPrior_indel(int famIdx)
{
  prior_indel = 0;
  if(ped->families[famIdx]->founders==0)
    error("Family size is zero\n");

  for(int i=1; i<=2*ped->families[famIdx]->founders; i++) //number of chromosomes
    prior_indel += 1.0 / i;
  prior_indel *= par.theta_indel;
}

double FamilyLikelihoodDN::GetPolyPrior(int famIdx) {
// if(prior==0.0) 
 {
  //if(isChrX) SetPolyPrior_chrX(); 
  //else if(isChrY) SetPolyPrior_chrY(); 
  //else if(isMT) SetPolyPrior_MT(); 
  //else SetPolyPrior();
  SetPolyPrior(famIdx);
  return(prior);
 }
}


double FamilyLikelihoodDN::GetPolyPrior_indel(int famIdx) {
//if(prior==0.0)
 SetPolyPrior_indel(famIdx);
return(prior);
}

*/

void FamilyLikelihoodDN::SetVCFInput(std::string vcfInput)
{
  vcfInFile = vcfInput;
}

void FamilyLikelihoodDN::denovo_calling()
{
 VCFInputFile vcfinput(par.vcfInFile.c_str());
 vin = &vcfinput;

 //Set up included PIDs and META data
 std::vector<std::string> pids;
 vin->getVCFHeader()->getPeopleName(&pids);

 includedPIDs.clear();
 included.clear();

 for(int i=0; i<pids.size(); i++)
 {
        std::map<std::string, std::pair<int, int> >::iterator it;
        it = pid2traverse.find(pids[i]);
        if(it!=pid2traverse.end() ) {
                includedPIDs.push_back(pids[i]);
                included[pids[i]]=1;
        }
 }

  vin->includePeople(includedPIDs);

  Person *p;
  std::string header = "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT";
  for(int i=0; i<ped->familyCount; i++)
  {
    p = ped->persons[ped->families[i]->path[0]];

    if(sexes[i][0]==1) {
	header += "\t";
	header += std::string(ped->persons[ped->families[i]->path[0]]->pid.c_str());
	header += "\t";
	header += std::string(ped->persons[ped->families[i]->path[1]]->pid.c_str());
    }
    else if(sexes[i][0]==2) {
	header += "\t";
	header += std::string(ped->persons[ped->families[i]->path[1]]->pid.c_str());
	header += "\t";
	header += std::string(ped->persons[ped->families[i]->path[0]]->pid.c_str());
    }
    else  error("Sex has to be 1 for father and 2 for monther!\n");

    for(int j=2; j<ped->families[i]->count; j++)
    {
     p = ped->persons[ped->families[i]->path[j]];
     header += "\t";
     header += std::string(p->pid.c_str());
   }
  }

  std::string meta_data;
  meta_data = "##fileformat=VCFv4.1\n";
  meta_data += "##triodenovo=";
  meta_data += par.cmd;
  meta_data += "\n";
  meta_data = meta_data +"##Note=VCF file modified by polymutt. Updated fileds include: QUAL, GT and GQ, AF and AC. NOTE: modification was applied only to biallelic variants\n" +
        "##FILTER=<ID=LOWDP,Description=\"Low Depth filter when the average depth per sample is lessn than 1\">\n" +
        "##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Total Read Depth\">\n" +
        "##INFO=<ID=AF,Number=A,Type=Float,Description=\"Alternative Allele Frequency\">\n" +
        "##INFO=<ID=AC,Number=1,Type=Integer,Description=\"Alternative Allele Count\">\n" +
        "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n" +
        "##FORMAT=<ID=DQ,Number=1,Type=Denovo Quality,Description=\"Denovo Quality: log10(BF) where BF is Bayes Factor calculated as L(M1)/L(M0) for M1 and M0 representing models with and without de novo mutations\">\n" +
        "##FORMAT=<ID=DGQ,Number=1,Type=Integer,Description=\"Denovo Genotype Quality: -10*log10(post) where post is the posterior probability of the called trio genotypes among all trios with de novo mutations\">\n" +
        "##FORMAT=<ID=DP,Number=1,Type=Integer,Description=\"Read Depth\">\n" +
        "##FORMAT=<ID=PL,Number=3,Type=Integer,Description=\"Phred-scaled Genotype Likelihoods\">\n" +
        "##FORMAT=<ID=GL,Number=3,Type=Float,Description=\"Log10 Genotype Likelihoods\">\n" +
        header + "\n";


 FILE *outVCF = fopen(par.vcfOutFile.c_str(), "w");
 if(outVCF==NULL) error("Open outpuf VCF file %f failed!\n", par.vcfOutFile.c_str() );
 fprintf(outVCF, "%s", meta_data.c_str() );

 bool flag = false;

 while(vin->readRecord())
 {
   FillPenetrance();

  if(flag==false) { printf("Total samples in both VCF and PED files: %d\n\n", nSamplesWithData); flag = true; }

  if(withdata_cnt==0 || isBiallelic==false) continue;

  if(String((*r).getChrom()) == par.chrX_label) isChrX = true; else isChrX = false;
  //else if(String((*r).getChrom()) == par.chrY_label) SetNonAutosomeFlags(false, true, false);
  //else if(String((*r).getChrom()) == par.MT_label) SetNonAutosomeFlags(false, false, true);
  //else SetNonAutosomeFlags(false, false, false);

 double logbf_max = -1.0;
 TrioConfigInfo trio;

 for(int i=0; i<ped->familyCount; i++)
 {
  double logbf = denovo_calling_single_trio(i, trio);

  trio.logbf = logbf;
  trio.posterior = trio.lk_joint_max/trio.lk;
  trio.qual = -10*log10(1-trio.posterior);
  if(trio.qual>100) trio.qual = 100;

  trio_info[i] = trio;

  if(logbf> logbf_max) logbf_max = logbf;
 }

 // Output denovo calling for all trios to VCF file if one trio reached the threshold
  if(logbf_max>par.min_lbf) OutputVCF(outVCF);

 } //end of vin

 fclose(outVCF);
}

double FamilyLikelihoodDN::denovo_calling_single_trio(int famIdx, TrioConfigInfo& trio)
{
 double lkM0 = CalcLikelihoodM0(famIdx);
 double lkM1 = CalcLikelihoodM1(famIdx, trio);

 double logbf = log10(lkM1) - log10(lkM0);
 return logbf;
}

double FamilyLikelihoodDN::CalcLikelihoodM0(int famIdx)
{
  double lk = 0.0;

  int sex = sexes[famIdx][2]; //the first child of the couple

  for(int i=0; i<3; i++)
   for(int j=0; j<3; j++)
   {
    for(int k=0; k<3; k++) {
     if(!isChrX) lk += fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 0 : 1][genotype_index[i]] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 1 : 0][genotype_index[j]] *
     fam[famIdx].penetrances[2][genotype_index[k]] *
     fam[famIdx].transmission_BA[i][j][k];

     if(isChrX && sex==FEMALE) lk += fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 0 : 1][genotype_index[i]] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 1 : 0][genotype_index[j]] *
     fam[famIdx].penetrances[2][genotype_index[k]] *
     fam[famIdx].transmission_BA_CHRX_2Female[i][j][k];

     if(isChrX && sex==MALE) lk += fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 0 : 1][genotype_index[i]] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 1 : 0][genotype_index[j]] *
     fam[famIdx].penetrances[2][genotype_index[k]] *
     fam[famIdx].transmission_BA_CHRX_2Male[i][j][k];
    }
   }

  return(lk);
}

double FamilyLikelihoodDN::CalcLikelihoodM1(int famIdx)
{
  double lk = 0;

  for(int i=0; i<3; i++)
   for(int j=0; j<3; j++)
   {
    for(int k=0; k<10; k++)
    {
     lk += fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[0][genotype_index[i]] *
     fam[famIdx].penetrances[1][genotype_index[j]] *
     fam[famIdx].penetrances[2][k] *
     fam[famIdx].transmission_denovo_post[genotype_index[i]][genotype_index[j]][k];
    }
   }

  return(lk);
}

//chrX is not finished yet. need to work on it later. (3/19/2014 update: readlly? I thought it was finished. hmmm...)
double FamilyLikelihoodDN::CalcLikelihoodM1(int famIdx, TrioConfigInfo& trio)
{
  double lk = 0;
  trio.lk_joint_max = -1.0;

  int sex = sexes[famIdx][2]; //the first child of the couple

  for(int i=0; i<3; i++)
   for(int j=0; j<3; j++)
   {
    for(int k=0; k<10; k++)
    {
     double lk_joint;

     if(!(genotype_index[i]==0 || genotype_index[i]==4 || genotype_index[i]==7 || genotype_index[i]==9)) continue;

     if(!isChrX) lk_joint = fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 0 : 1][genotype_index[i]] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 1 : 0][genotype_index[j]] *
     fam[famIdx].penetrances[2][k] *
     fam[famIdx].transmission_denovo_post[genotype_index[i]][genotype_index[j]][k];

     if(isChrX && sex==FEMALE) lk_joint = fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 0 : 1][genotype_index[i]] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 1 : 0][genotype_index[j]] *
     fam[famIdx].penetrances[2][k] *
     fam[famIdx].transmission_CHRX_2Female_denovo_post[genotype_index[i]][genotype_index[j]][k];

     if(isChrX && sex==MALE) lk_joint = fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 0 : 1][genotype_index[i]] *
     fam[famIdx].penetrances[sexes[famIdx][0]==1 ? 1 : 0][genotype_index[j]] *
     fam[famIdx].penetrances[2][k] *
     fam[famIdx].transmission_CHRX_2Male_denovo_post[genotype_index[i]][genotype_index[j]][k];

     if(lk_joint>trio.lk_joint_max) {
      trio.lk_joint_max = lk_joint; trio.p1 = i; trio.p2 = j; trio.child=k;
     }

     lk += lk_joint;
    }
   }
  trio.lk = lk;

  return(lk);
}

double FamilyLikelihoodDN::CalcLikelihoodM11(int famIdx)
{
  double lk = 0;

  for(int i=0; i<3; i++)
   for(int j=0; j<3; j++)
   {
    for(int k=0; k<10; k++)
     lk += fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[0][genotype_index[i]] *
     fam[famIdx].penetrances[1][genotype_index[j]] *
     fam[famIdx].penetrances[2][k] *
     fam[famIdx].transmission_denovo[genotype_index[i]][genotype_index[j]][k];
   }

  return(lk);
}

double FamilyLikelihoodDN::CalcLikelihoodM00(int famIdx)
{
  double lk = 0;

  for(int i=0; i<3; i++)
   for(int j=0; j<3; j++)
   {
    for(int k=0; k<10; k++)
     lk += fam[famIdx].parentPrior[i*3+j] *
     fam[famIdx].penetrances[0][genotype_index[i]] *
     fam[famIdx].penetrances[1][genotype_index[j]] *
     fam[famIdx].penetrances[2][k] *
     fam[famIdx].transmission[genotype_index[i]][genotype_index[j]][k];
   }

  return(lk);
}

int FamilyLikelihoodDN::GenotypeIndex(int base1, int base2)
{
   return base1 < base2 ? (base1 - 1) * (10 - base1) / 2 + (base2 - base1) :
                          (base2 - 1) * (10 - base2) / 2 + (base1 - base2);
}

void FamilyLikelihoodDN::OutputVCF(FILE* ofh)
{
int bestIdx;
int GTQual;

std::map<std::string, std::pair<int, int> >::iterator it;

if(isBiallelic==false) return;

bool missing = false;
VCFIndividual* indv;
int AC = 0;
int totalSamplesWithDepth = 0;
int totalDepth = 0;
std::string pid;
std::map<std::pair<int, int>, std::string> DP_str;
std::map<std::pair<int, int>, int> DP_int;
std::map<std::pair<int, int>, std::string> PL_str;

DP_str.clear();
DP_int.clear();
PL_str.clear();

for(int i=0; i<people->size(); i++) 
{
        indv = (*people)[i];
        pid = (*indv).getName();

        if(pid2traverse.count((*indv).getName())==0) continue;

        if(included[pid]>0==false) continue; 

        std:pair<int, int> fam_pid = pid2traverse[pid];
        //AC += bestGenoIdx[fam_pid.first][fam_pid.second]; 

        DP_str[fam_pid] = std::string(DP_index>0 ? (*indv).get(DP_index, &missing).toStr() : ".");
        PL_str[fam_pid] = std::string((*indv).get(PL_idx>0 ? PL_idx : GL_idx, &missing).toStr());

	int dp =  DP_index>0 ? (*indv).get(DP_index, &missing).toInt() : 0;
        DP_int[fam_pid] = dp;

        if(missing) continue;

        totalDepth+=dp;
        totalSamplesWithDepth++;

}

  if(DP_index>=0 && par.maxTotalDepth>0 && (totalDepth>par.maxTotalDepth || totalDepth<par.minTotalDepth)) return;

char buff[100];
sprintf(buff,"%d", totalDepth);
std::string dpInfo("DP=");
dpInfo += std::string(buff);

std::vector<bool> depthFilter;
depthFilter.resize(ped->familyCount, false);
int depthFilterCnt=0;

 for(int i=0; i<ped->familyCount; i++)
 {
	if(DP_int[std::pair<int,int>(i,0)]<par.minDepthInTrio && DP_index>0) depthFilter[i] = true;
	if(DP_int[std::pair<int,int>(i,1)]<par.minDepthInTrio && DP_index>0) depthFilter[i] = true;
	if(DP_int[std::pair<int,int>(i,2)]<par.minDepthInTrio && DP_index>0) depthFilter[i] = true;

	if(depthFilter[i]==true) depthFilterCnt++;
 }

 if(depthFilterCnt==ped->familyCount) return;

fprintf(ofh, "%s\t%d\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
                         r->getChrom(),
                         r->getPos(),
                         r->getID(),
                         r->getRef(),
                         r->getAlt(),
                         r->getQual(),
                         r->getFilt(),
                         dpInfo.c_str(),
                         PL_idx>0 ? "GT:DQ:DGQ:DP:PL" : "GT:DQ:DGQ:DP:GL" //r->getFormat()
        );

 for(int i=0; i<ped->familyCount; i++)
  {
        std::pair<int, int> fam_pid;

        int p1_idx = trio_info[i].p1;
        int p2_idx = trio_info[i].p2;
        int child_idx = trio_info[i].child;

	std::string p1_gt = isChrX ? genotype10_labels_X_Male[genotype_index[p1_idx]] : genotype10_labels[genotype_index[p1_idx]];
	std::string p2_gt = genotype10_labels[genotype_index[p2_idx]];
	std::string child_gt = isChrX && sexes[i][2]==MALE ? genotype10_labels_X_Male[child_idx] : genotype10_labels[child_idx];

	double logbf = trio_info[i].logbf;
	int GQ = int(trio_info[i].qual);

	if(logbf<par.min_lbf || depthFilter[i]) {
 	  p1_gt = isChrX ? std::string(".") : std::string("./."); 
	  p2_gt = std::string("./.");
	  child_gt = isChrX && sexes[i][2]==MALE ? std::string(".") : std::string("./."); 
	  GQ = -1;
 	}

        fam_pid.first = i;
        fam_pid.second = sexes[i][0]==1 ? 0 : 1; //If the first parent is father process the first perosn, otherwise process the second person. This is to have father, mother and child order in the VCF file
        fprintf(ofh, "\t");
	fprintf(ofh, "%s:", p1_gt.c_str());
	fprintf(ofh, "%.2f:", logbf);
	GQ>=0 ? fprintf(ofh, "%d:", GQ) : fprintf(ofh, ".:");
        fprintf(ofh, "%s:", DP_str[fam_pid].c_str());
        fprintf(ofh, "%s",  PL_str[fam_pid].c_str() );

	fam_pid.second = sexes[i][0]==1 ? 1 : 0; //The same the above
        fprintf(ofh, "\t");
	fprintf(ofh, "%s:", p2_gt.c_str());
	fprintf(ofh, "%.2f:", logbf);
	GQ>=0 ? fprintf(ofh, "%d:", GQ) : fprintf(ofh, ".:");
        fprintf(ofh, "%s:", DP_str[fam_pid].c_str());
        fprintf(ofh, "%s",  PL_str[fam_pid].c_str() );

	fam_pid.second = 2;
        fprintf(ofh, "\t");
	fprintf(ofh, "%s:", child_gt.c_str());
	fprintf(ofh, "%.2f:", logbf);
	GQ>=0 ? fprintf(ofh, "%d:", GQ) : fprintf(ofh, ".:");
        fprintf(ofh, "%s:", DP_str[fam_pid].c_str());
        fprintf(ofh, "%s",  PL_str[fam_pid].c_str() );
    }

   fprintf(ofh, "\n");
   fflush(ofh);
}
